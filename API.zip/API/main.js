const {pool,client} = require('./db');

const express = require('express');
const app = express();
app.use(express.json());
const port = 3000;
app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
  });

  const database = client.db('test');
  const treinos = database.collection('Treinos');

app.get('/', async (req,res) => {
  pool.connect(function(err) {
    if (err) throw err;
    res.status(200).send("Conectado")
  });

})

app.post('/addTreino', async (req,res) => {
  await client.connect()
  let dados = req.body
  console.log(dados)
  const resultFind = await treinos.findOne({User:"admin"})
  if(resultFind === null){
    try{
      let query = {
        "User": dados.User,
        "Treino": dados.Treino
      }
      console.log(query)
      treinos.insertOne(query)
    }
    catch(e){
      console.log(e)
    }
  }
  else{
    try{
      const updateResult = await treinos.updateOne({ User: dados.User }, { $set: { Treino: dados.Treino } });
      console.log(updateResult)
    }
    catch(e){
      console.log(e)
    }
  }

})

app.get('/getTreino', async (req,res) => {
  await client.connect()
  let dados = req.query
  console.log(dados)
  const resultFind = await treinos.findOne({User:dados.User})
  console.log(typeof(resultFind.Treino[0].Repeticoes))
  res.send(resultFind.Treino);
})

app.post('/signup', async (req, res) => {
  pool.connect(function(err) {
    if (err) throw err;
    res.status(200).send("Conectado")
  });
    console.log(req.body);
    const dados = req.body;
    console.log(dados.email)
    //console.log(dados[0].email)
    try {
        pool.query('INSERT into User (email,senha) values (?, ?);',
        [dados.email,dados.senha])
        //console.log(user);
      } catch(e){
        console.log(e);
      }

      //res.send('Sucessfull sign in!');

      
});

app.post('/login', async (req, res) => {
  pool.connect(function(err) {
    if (err) throw err;
    else console.log("Conectado!")
  });
    const dados = req.body;
    console.log(typeof(dados.email));
    try{
      pool.query('SELECT * from User where `email` = ? ;',[dados.email],
      async (err,result) => {
        console.log()
         if(Objetovazio(result)){
             
             console.log("\nUsuario nao encontrado!")
           }
           else{
             console.log("\nEMAIL CORRETO")
             let ver_pass = false;
             if(dados.senha === result[0].senha){
              ver_pass = true;
             }
     
             if(!ver_pass){
               console.log("\nSenha invalida!");
               res.status(401).send("Login inválido!");
             }
             else{
               console.log("\nSENHA CORRETA, USUARIO LOGADO");
            
               res.status(200).send("Logado!!");
             }
         }
     });
    }
    catch(e){
      console.log(e)
    }
      
});

// banco de dados guitos


function Objetovazio(obj) {
  for (var prop in obj) {
    if(obj.hasOwnProperty(prop)) 
      return false
  }
  return true;
}



