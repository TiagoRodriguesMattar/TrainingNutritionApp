const mysql_pool = require('mysql2')

const { MongoClient } = require("mongodb");

require('dotenv').config()

const pool = mysql_pool.createConnection({
    host: 'viaduct.proxy.rlwy.net',//process.env.MYSQL_HOST,
    user: 'root',//process.env.MYSQL_USER,
    database: 'railway',//process.env.MYSQL_DATABASE,
    password: 'GHfcbdDbbEAC5h32g-2gCbFFaccGaf2e',//process.env.MYSQL_PASSWORD,
    port: '33191'//process.env.MYSQL_PORT
  });

const client = new MongoClient(process.env.URI);

module.exports = {pool,client}